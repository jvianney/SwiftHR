CREATE TRIGGER `main_interviewdetails_aft_upd`
AFTER UPDATE ON `main_interviewdetails`
FOR EACH ROW
  BEGIN
					if old.interview_status != new.interview_status then 
				        begin 
					update main_interviewrounds_summary set interview_status = new.interview_status,modified_date = utc_timestamp() where interview_id = new.id and isactive = 1;
					end;
				        end if;
				    END