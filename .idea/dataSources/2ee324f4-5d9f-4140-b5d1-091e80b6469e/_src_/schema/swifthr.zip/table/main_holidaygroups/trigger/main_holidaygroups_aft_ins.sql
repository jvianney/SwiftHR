CREATE TRIGGER `main_holidaygroups_aft_ins`
AFTER UPDATE ON `main_holidaygroups`
FOR EACH ROW
  BEGIN
				    if old.groupname != new.groupname then 
				    begin 
					update main_employees_summary set holiday_group_name = new.groupname,modifieddate = utc_timestamp() where isactive = 1 and holiday_group = new.id;
				    end;
				    end if;
				    END