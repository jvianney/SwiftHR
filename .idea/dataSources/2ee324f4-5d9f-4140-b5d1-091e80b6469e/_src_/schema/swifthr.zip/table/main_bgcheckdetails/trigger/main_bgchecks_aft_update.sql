CREATE TRIGGER `main_bgchecks_aft_update`
AFTER UPDATE ON `main_bgcheckdetails`
FOR EACH ROW
  BEGIN
					declare detailid,specimen_id, specimen_name, emp_id, specimen_flag_name, agency_name, 
						screening_type, created_name, modified_name,createdbyname,
						modifiedbyname varchar(250);
					declare	specimen_flag_id,agency_id,screeningtype_id int(11);
					select id,flag,if(flag=1,'Employee','Candidate')
						into detailid,specimen_flag_id,specimen_flag_name
						from main_bgcheckdetails where id = new.id;
					if(specimen_flag_id = 1)then
						select userfullname,id, employeeId into specimen_name,specimen_id,emp_id from main_users where id = new.specimen_id;
					end if;
					if(specimen_flag_id = 2) then
						select candidate_name,id into specimen_name,specimen_id from main_candidatedetails where id = new.specimen_id;
					end if;
					select userfullname into createdbyname from main_users where id = new.createdby;
					select userfullname into modifiedbyname from main_users where id = new.modifiedby;
					select id,agencyname into agency_id,agency_name from main_bgagencylist where id = new.bgagency_id;
					select id,type into screeningtype_id,screening_type from main_bgchecktype where id = new.bgcheck_type;
					UPDATE  main_bgchecks_summary set	
					detail_id = new.id , 
					specimen_name = specimen_name , 
					specimen_id = specimen_id , 
					specimen_flag = specimen_flag_id , 
					specimen_flag_name = specimen_flag_name , 
					employee_id = emp_id , 
					screeningtypeid = screeningtype_id , 
					screeningtype_name = screening_type , 
					agencyid = agency_id , 
					agencyname = agency_name , 
					process_status = new.process_status , 
					modifieddate = new.modifieddate, 
					modifiedby = new.modifiedby , 
					modifiedname = modifiedbyname , 
					isactive = new.isactive , 
					isactive_text = if(new.isactive = 0,'Process deleted',if(new.isactive = 1,'Active',if(new.isactive = 2,'Agency deleted',if(new.isactive = 3,'Agency User deleted',if(new.isactive = 4,'POC deleted','Active')))))
					where
					detail_id = new.id ;
				    END