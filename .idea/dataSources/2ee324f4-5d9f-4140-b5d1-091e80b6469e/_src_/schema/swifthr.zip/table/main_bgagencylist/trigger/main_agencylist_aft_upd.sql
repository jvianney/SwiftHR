CREATE TRIGGER `main_agencylist_aft_upd`
AFTER UPDATE ON `main_bgagencylist`
FOR EACH ROW
  BEGIN
					if(old.agencyname != new.agencyname) then
					update main_bgchecks_summary set agencyname = new.agencyname,modifieddate = utc_timestamp() where agencyid = new.id and isactive = 1;
					end if;
				    END