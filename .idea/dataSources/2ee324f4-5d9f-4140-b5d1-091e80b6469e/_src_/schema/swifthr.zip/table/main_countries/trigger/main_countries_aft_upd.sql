CREATE TRIGGER `main_countries_aft_upd`
AFTER UPDATE ON `main_countries`
FOR EACH ROW
  BEGIN
					if old.country != new.country then 
					begin 
					update main_interviewrounds_summary set interview_country_name = new.country,modified_date = utc_timestamp() where interview_country_id = new.country_id_org and isactive = 1;
					end;
					end if;
				    END