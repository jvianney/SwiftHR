CREATE TRIGGER `main_screeningtype_aft_upd`
AFTER UPDATE ON `main_bgchecktype`
FOR EACH ROW
  BEGIN
					if(old.type != new.type) then
					update main_bgchecks_summary set screeningtype_name = new.type,modifieddate = utc_timestamp() where screeningtypeid = new.id and isactive = 1;
					end if;
				    END