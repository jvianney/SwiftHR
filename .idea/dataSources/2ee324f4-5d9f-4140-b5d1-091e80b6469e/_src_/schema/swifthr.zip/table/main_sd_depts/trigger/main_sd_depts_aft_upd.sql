CREATE TRIGGER `main_sd_depts_aft_upd`
AFTER UPDATE ON `main_sd_depts`
FOR EACH ROW
  BEGIN
					if old.service_desk_name != new.service_desk_name then 
        			begin 
           				update main_sd_requests_summary set service_desk_name = new.service_desk_name,modifieddate = utc_timestamp() where service_desk_id = new.id;
        			end;
        			end if;
    				END