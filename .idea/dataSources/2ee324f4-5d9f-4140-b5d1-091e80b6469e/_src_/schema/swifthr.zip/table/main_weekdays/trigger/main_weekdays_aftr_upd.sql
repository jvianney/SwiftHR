CREATE TRIGGER `main_weekdays_aftr_upd`
AFTER UPDATE ON `main_weekdays`
FOR EACH ROW
  BEGIN
			        declare weekend_name varchar(200);
			        select week_name into weekend_name from tbl_weeks where week_id = new.day_name;
			        UPDATE main_leavemanagement_summary lm SET lm.weekend_startdayname = weekend_name, lm.modifieddate = utc_timestamp() 
			        WHERE (lm.weekend_startday = new.day_name AND lm.isactive=1);
			        UPDATE main_leavemanagement_summary lm SET lm.weekend_enddayname = weekend_name, lm.modifieddate = utc_timestamp() 
			        WHERE (lm.weekend_endday = new.day_name AND lm.isactive=1);
			    	END