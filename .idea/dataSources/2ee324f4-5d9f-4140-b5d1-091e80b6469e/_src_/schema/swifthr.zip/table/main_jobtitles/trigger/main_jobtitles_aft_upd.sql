CREATE TRIGGER `main_jobtitles_aft_upd`
AFTER UPDATE ON `main_jobtitles`
FOR EACH ROW
  BEGIN
				    if old.jobtitlename != new.jobtitlename then 
				    begin 
					update main_requisition_summary set jobtitle_name = new.jobtitlename,modifiedon = utc_timestamp() where isactive = 1 and jobtitle = new.id;
					update main_employees_summary set jobtitle_name = new.jobtitlename,modifieddate = utc_timestamp() where isactive = 1 and jobtitle_id = new.id;
				    end;
				    end if;
				    
				    END