CREATE TRIGGER `main_employeeleavetypes_aft_upd`
AFTER UPDATE ON `main_employeeleavetypes`
FOR EACH ROW
  BEGIN
				     update main_leaverequest_summary ls set ls.leavetype_name = new.leavetype,ls.modifieddate = utc_timestamp() 
				     where ls.leavetypeid = new.id and ls.isactive = 1;
				    END