CREATE TRIGGER `main_positions_main_requisition_summary`
AFTER UPDATE ON `main_positions`
FOR EACH ROW
  BEGIN
					UPDATE main_requisition_summary rs SET rs.position_name = NEW.positionname, rs.modifiedon = utc_timestamp() WHERE (rs.position_id = NEW.id 
					AND rs.position_name != NEW.positionname);
					update main_employees_summary set position_name = new.positionname,modifieddate = utc_timestamp() where position_id = new.id and isactive = 1;
				    END