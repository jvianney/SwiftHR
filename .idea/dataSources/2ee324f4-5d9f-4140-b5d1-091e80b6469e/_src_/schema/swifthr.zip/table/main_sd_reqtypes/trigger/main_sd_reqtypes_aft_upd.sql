CREATE TRIGGER `main_sd_reqtypes_aft_upd`
AFTER UPDATE ON `main_sd_reqtypes`
FOR EACH ROW
  BEGIN
					if old.service_request_name != new.service_request_name then 
				        begin 
				           update main_sd_requests_summary set service_request_name = new.service_request_name,modifieddate = utc_timestamp() where service_request_id = new.id;
				        end;
				        end if;
				    END