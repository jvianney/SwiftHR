CREATE TRIGGER `main_identitycodes_aft_upd`
AFTER UPDATE ON `main_identitycodes`
FOR EACH ROW
  BEGIN
				    if old.employee_code != new.employee_code then 
				    begin
					update main_users set employeeId = replace(employeeId,SUBSTRING(employeeId,1,CHAR_LENGTH(old.employee_code)),new.employee_code),modifieddate = utc_timestamp() where SUBSTRING(employeeId,1,CHAR_LENGTH(old.employee_code)) = old.employee_code;
				    end;
				    end if;
				    if old.backgroundagency_code != new.backgroundagency_code then 
				    begin
					update main_users set employeeId = replace(employeeId,SUBSTRING(employeeId,1,CHAR_LENGTH(old.backgroundagency_code)),new.backgroundagency_code),modifieddate = utc_timestamp() where SUBSTRING(employeeId,1,CHAR_LENGTH(old.backgroundagency_code)) = old.backgroundagency_code;
				    end;
				    end if;
				    if old.users_code != new.users_code then 
				    begin
					update main_users set employeeId = replace(employeeId,SUBSTRING(employeeId,1,CHAR_LENGTH(old.users_code)),new.users_code),modifieddate = utc_timestamp() where SUBSTRING(employeeId,1,CHAR_LENGTH(old.users_code)) = old.users_code;
				    end;
				    end if;	
				    if old.requisition_code != new.requisition_code then 
				    begin
					update main_requisition r set r.requisition_code = replace(r.requisition_code,left(r.requisition_code,LOCATE('/',r.requisition_code)),CONCAT(new.requisition_code,'/')),r.modifiedon = utc_timestamp() where left(r.requisition_code,LOCATE('/',r.requisition_code)) = CONCAT(old.requisition_code,'/');
				    end;
				    end if;
				    END