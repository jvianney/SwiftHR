CREATE TRIGGER `main_sd_request_aft_upd`
AFTER UPDATE ON `main_sd_requests`
FOR EACH ROW
  BEGIN
					DECLARE x_service_desk_name,x_service_request_name,x_raised_by_name,x_executor_name,
						x_reporting_manager_name,x_approver_1_name,x_approver_2_name,x_approver_3_name
						VARCHAR(250);
					
					IF(new.request_for=1) THEN
					SELECT service_desk_name INTO x_service_desk_name FROM main_sd_depts WHERE id = new.service_desk_id;
					SELECT service_request_name INTO x_service_request_name FROM main_sd_reqtypes WHERE id = new.service_request_id;
					ELSE
					SELECT NAME INTO x_service_desk_name FROM assets WHERE id = new.service_desk_id;
					SELECT NAME INTO x_service_request_name FROM assets_categories WHERE id = new.service_request_id AND parent=0;
					END IF;
					SELECT userfullname INTO x_raised_by_name FROM main_employees_summary WHERE user_id = new.raised_by;
					SELECT userfullname INTO x_executor_name FROM main_employees_summary WHERE user_id = new.executor_id;
					SELECT userfullname INTO x_reporting_manager_name FROM main_employees_summary WHERE user_id = new.reporting_manager_id;
					SELECT userfullname INTO x_approver_1_name FROM main_employees_summary WHERE user_id = new.approver_1;
					SELECT userfullname INTO x_approver_2_name FROM main_employees_summary WHERE user_id = new.approver_2;
					SELECT userfullname INTO x_approver_3_name FROM main_employees_summary WHERE user_id = new.approver_3;
					
					UPDATE main_sd_requests_summary SET
					request_for=new.request_for,service_desk_id = new.service_desk_id, service_desk_name = x_service_desk_name, service_desk_conf_id = new.service_desk_conf_id,
					service_request_name = x_service_request_name, service_request_id = new.service_request_id, priority = new.priority,
					description = new.description, attachment = new.attachment, STATUS = new.status, raised_by = new.raised_by,
					raised_by_name = x_raised_by_name, ticket_number = new.ticket_number, executor_id = new.executor_id, executor_name = x_executor_name,
					executor_comments = new.executor_comments, reporting_manager_id = new.reporting_manager_id, reporting_manager_name = x_reporting_manager_name,
					approver_status_1 = new.approver_status_1, approver_status_2 = new.approver_status_2, approver_status_3 = new.approver_status_3,
					reporting_manager_status = new.reporting_manager_status, approver_1 = new.approver_1, approver_1_name = x_approver_1_name,
					approver_2 = new.approver_2, approver_2_name = x_approver_2_name, approver_3 = new.approver_3, approver_3_name = x_approver_3_name,
					isactive = new.isactive, createdby = new.createdby, modifiedby = new.modifiedby, createddate = new.createddate, modifieddate = new.modifieddate
					,approver_1_comments = new.approver_1_comments,approver_2_comments = new.approver_2_comments,approver_3_comments = new.approver_3_comments,reporting_manager_comments = new.reporting_manager_comments,
					to_mgmt_comments = new.to_mgmt_comments,to_manager_comments = new.to_manager_comments
					WHERE sd_requests_id = new.id;
					END