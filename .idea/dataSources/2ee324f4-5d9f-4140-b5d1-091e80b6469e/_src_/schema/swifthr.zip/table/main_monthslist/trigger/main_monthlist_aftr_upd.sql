CREATE TRIGGER `main_monthlist_aftr_upd`
AFTER UPDATE ON `main_monthslist`
FOR EACH ROW
  BEGIN
			        declare calmonth_name varchar(200);
			        select month_name into calmonth_name from tbl_months where monthid = new.month_id;
			        UPDATE main_leavemanagement_summary lm SET lm.cal_startmonthname = calmonth_name, lm.modifieddate = utc_timestamp() 
			        WHERE (lm.cal_startmonth = new.month_id AND lm.isactive=1);
			    	END