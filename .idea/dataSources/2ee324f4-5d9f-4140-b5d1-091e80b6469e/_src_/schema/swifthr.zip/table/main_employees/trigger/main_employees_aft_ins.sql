CREATE TRIGGER `main_employees_aft_ins`
AFTER INSERT ON `main_employees`
FOR EACH ROW
  BEGIN
					declare user_id,fname,lname,username,role_name,rep_name,emp_status,bunit_name,dept_name,job_name,pos_name,prefix_name,
						createdbyname,holidaygrp,modifiedbyname,emailid,cnumber,bgstatus,empid,mode_entry,omode_entry,sel_date,
				                ref_by_name,img_src
						varchar(250);
					declare ref_by_id,role_id int(11);
					select firstname,lastname,userfullname,emailaddress,contactnumber,backgroundchk_status,employeeId,modeofentry,other_modeofentry,selecteddate,candidatereferredby,
				               profileimg,emprole  
						into fname,lname,username,emailid,cnumber,bgstatus,empid,mode_entry,omode_entry,sel_date,ref_by_id,img_src,role_id 
					from main_users where id = new.user_id;
					select userfullname into rep_name from main_users where id = new.reporting_manager;
				/*
					select employemnt_status into emp_status from tbl_employmentstatus where id = (select workcodename 
					from main_employmentstatus where id = new.emp_status_id);*/
					select employemnt_status into emp_status from tbl_employmentstatus where id = new.emp_status_id	;
					set user_id = new.user_id;
					set bunit_name = null;
					if new.businessunit_id is not null then
						select unitname into bunit_name from main_businessunits where id = new.businessunit_id;
					end if;
					set holidaygrp = null;
					if new.holiday_group is not null then
						select groupname into holidaygrp from main_holidaygroups where id = new.holiday_group;
					end if;
					select deptname into dept_name from main_departments where id = new.department_id;
					select jobtitlename into job_name from main_jobtitles where id = new.jobtitle_id;
					select positionname into pos_name from main_positions where id = new.position_id;
					select prefix into prefix_name from main_prefix where id = new.prefix_id;
					select userfullname into createdbyname from main_users where id = new.createdby;
					select rolename into role_name from main_roles where id = role_id;
					if (ref_by_id != '' and ref_by_id > 0) then 
				        begin 
					    select userfullname into ref_by_name from main_users where id = ref_by_id;
				        end;
				        end if;
				insert into main_employees_summary ( 
					user_id, date_of_joining, date_of_leaving, reporting_manager, reporting_manager_name, emp_status_id, 
					emp_status_name, businessunit_id, businessunit_name, department_id, department_name, jobtitle_id, 
					jobtitle_name, position_id, position_name, years_exp, holiday_group, holiday_group_name, 
					prefix_id, prefix_name, extension_number, office_number, office_faxnumber, emprole, 
					emprole_name, firstname,lastname,userfullname, emailaddress, contactnumber, backgroundchk_status, 	employeeId, 
					modeofentry, other_modeofentry, selecteddate, candidatereferredby, referer_name, profileimg, 
					createdby, createdby_name, modifiedby, createddate, modifieddate, isactive)
					values	(	
					new.user_id, new.date_of_joining, new.date_of_leaving,new.reporting_manager,rep_name,new.emp_status_id, 
					emp_status,new.businessunit_id,	bunit_name,new.department_id,dept_name,new.jobtitle_id, 
					job_name, new.position_id, pos_name,new.years_exp, new.holiday_group, holidaygrp, 
					new.prefix_id, 	prefix_name, new.extension_number, new.office_number, new.office_faxnumber,role_id, 
					role_name,fname,lname,username, emailid,cnumber,bgstatus,empid, 
					mode_entry,omode_entry,	sel_date, ref_by_id, ref_by_name,img_src, 
					new.createdby, 	createdbyname, new.modifiedby,new.createddate, new.modifieddate, new.isactive
					);
				    END