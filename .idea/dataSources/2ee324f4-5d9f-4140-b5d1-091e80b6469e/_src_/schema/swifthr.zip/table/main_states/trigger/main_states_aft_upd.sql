CREATE TRIGGER `main_states_aft_upd`
AFTER UPDATE ON `main_states`
FOR EACH ROW
  BEGIN
					if old.state != new.state then 
					begin 
					   update main_interviewrounds_summary set interview_state_name = new.state,modified_date = utc_timestamp() where interview_state_id = new.state_id_org and isactive = 1;
					end;
					end if;
				    END