CREATE TRIGGER `main_employmentstatus_main_requisition_summary`
AFTER UPDATE ON `main_employmentstatus`
FOR EACH ROW
  BEGIN
					declare empt_name varchar(250);
					UPDATE main_requisition_summary rs 
					LEFT JOIN main_employmentstatus mes ON mes.workcodename = rs.emp_type
					LEFT JOIN tbl_employmentstatus tes ON tes.id = mes.workcodename
					SET rs.emp_type_name = tes.employemnt_status, rs.modifiedon = utc_timestamp()
					WHERE (rs.emp_type_name != tes.employemnt_status);
					select te.employemnt_status into empt_name from main_employmentstatus em 
				       inner join tbl_employmentstatus te on te.id = em.workcodename where em.id = new.id;
					#start of main_employees_summary
					update main_employees_summary set emp_status_name = empt_name,modifieddate = utc_timestamp() where emp_status_id = new.id and isactive = 1;
					#end of main_employees_summary
				    END