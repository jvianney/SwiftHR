CREATE TRIGGER `main_roles_aft_upd`
AFTER UPDATE ON `main_roles`
FOR EACH ROW
  BEGIN
				    if old.rolename != new.rolename then 
				    begin 
					update main_employees_summary set emprole_name = new.rolename,modifieddate = utc_timestamp() where isactive = 1 and emprole = new.id;
				    end;
				    end if;
				    END