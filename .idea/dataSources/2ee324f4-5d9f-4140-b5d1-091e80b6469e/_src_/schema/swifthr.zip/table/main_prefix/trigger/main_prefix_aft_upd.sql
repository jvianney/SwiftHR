CREATE TRIGGER `main_prefix_aft_upd`
AFTER UPDATE ON `main_prefix`
FOR EACH ROW
  BEGIN
				    if old.prefix != new.prefix then 
				    begin 
				      update main_employees_summary set prefix_name = new.prefix,modifieddate = utc_timestamp() where isactive = 1 and prefix_id = new.id;
				    end;
				    end if;
				    END