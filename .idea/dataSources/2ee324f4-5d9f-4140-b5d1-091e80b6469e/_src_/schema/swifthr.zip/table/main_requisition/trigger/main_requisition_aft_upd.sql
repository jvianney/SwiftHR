CREATE TRIGGER `main_requisition_aft_upd`
AFTER UPDATE ON `main_requisition`
FOR EACH ROW
  BEGIN
					declare pos_name,rep_name,bunit_name,dept_name,job_name,empt_name,app1_name,app2_name,app3_name varchar(200);
					select positionname into pos_name from main_positions where id = new.position_id;
					select userfullname into rep_name from main_users where id = new.reporting_id;
					select userfullname into app1_name from main_users where id = new.approver1;
					set app2_name = null;
					set app3_name = null;
					if new.approver2 is not null then 
				        select userfullname into app2_name from main_users where id = new.approver2;
				        end if;
					
					if new.approver3 is not null then 
				        select userfullname into app3_name from main_users where id = new.approver3;
				        end if;
					select unitname into bunit_name from main_businessunits where id = new.businessunit_id;
					select deptname into dept_name from main_departments where id = new.department_id;
					select jobtitlename into job_name from main_jobtitles where id = new.jobtitle;
					select te.employemnt_status into empt_name from main_employmentstatus em 
				       inner join tbl_employmentstatus te on te.id = em.workcodename where em.id = new.emp_type;
					update main_requisition_summary set
					 requisition_code = new.requisition_code,onboard_date = new.onboard_date, position_id = new.position_id, position_name = pos_name, 
					 reporting_id = new.reporting_id, reporting_manager_name = rep_name , 
					businessunit_id = new.businessunit_id, businessunit_name = bunit_name, 
					department_id = new.department_id, department_name = dept_name, 
					jobtitle = new.jobtitle, jobtitle_name = job_name,	req_no_positions = new.req_no_positions, 
					selected_members = new.selected_members, filled_positions = new.filled_positions, 
					jobdescription = new.jobdescription, req_skills = new.req_skills, req_qualification = new.req_qualification, 
					req_exp_years = new.req_exp_years, 	emp_type = new.emp_type, emp_type_name = empt_name, 
					req_priority = new.req_priority, additional_info = new.additional_info, req_status = new.req_status,
					 approver1 = new.approver1, approver1_name = app1_name,	approver2 = new.approver2, 
					 approver2_name = app2_name, approver3 = new.approver3, approver3_name = app3_name, 
					 appstatus1 = new.appstatus1, appstatus2 = new.appstatus2, appstatus3 = new.appstatus3, 
					 modifiedby = new.modifiedby, 	modifiedon = new.modifiedon,isactive = new.isactive where req_id = new.id ;
					 
				    END