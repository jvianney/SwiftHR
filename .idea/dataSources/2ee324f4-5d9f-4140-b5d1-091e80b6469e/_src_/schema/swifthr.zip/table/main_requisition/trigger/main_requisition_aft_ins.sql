CREATE TRIGGER `main_requisition_aft_ins`
AFTER INSERT ON `main_requisition`
FOR EACH ROW
  BEGIN
					declare pos_name,rep_name,bunit_name,dept_name,job_name,empt_name,app1_name,app2_name,app3_name,createdbyname varchar(200);
					select positionname into pos_name from main_positions where id = new.position_id;
				        select userfullname into rep_name from main_users where id = new.reporting_id;
					select userfullname into app1_name from main_users where id = new.approver1;
					select userfullname into createdbyname from main_users where id = new.createdby;
				        set app2_name = null;
					set app3_name = null;
					if new.approver2 is not null then 
				        select userfullname into app2_name from main_users where id = new.approver2;
				        end if;
					
					if new.approver3 is not null then 
				        select userfullname into app3_name from main_users where id = new.approver3;
				        end if;
					select unitname into bunit_name from main_businessunits where id = new.businessunit_id;
					select deptname into dept_name from main_departments where id = new.department_id;
					select jobtitlename into job_name from main_jobtitles where id = new.jobtitle;
					select te.employemnt_status into empt_name from main_employmentstatus em 
				       inner join tbl_employmentstatus te on te.id = em.workcodename where em.id = new.emp_type;
				insert into main_requisition_summary 
					(req_id, requisition_code, onboard_date, position_id, position_name, reporting_id, reporting_manager_name, 
					businessunit_id, businessunit_name, department_id, department_name, jobtitle, jobtitle_name, 
					req_no_positions, selected_members, filled_positions, jobdescription, req_skills, req_qualification, 
					req_exp_years, 	emp_type, emp_type_name, req_priority, additional_info, req_status, approver1, approver1_name, 
					approver2, approver2_name, approver3, approver3_name, appstatus1, appstatus2, appstatus3, isactive, 
					createdby, modifiedby, 	createdon, modifiedon,createdby_name
					)
					values
					(new.id, 
					 
					new.requisition_code, 
					new.onboard_date, 
					new.position_id, 
					pos_name, 
					new.reporting_id, 
					rep_name, 
					new.businessunit_id, 
					bunit_name, 
					new.department_id, 
					dept_name, 
					new.jobtitle, 
					job_name, 
					new.req_no_positions, 
					new.selected_members, 
					new.filled_positions, 
					new.jobdescription, 
					new.req_skills, 
					new.req_qualification, 
					new.req_exp_years, 
					new.emp_type, 
					empt_name, 
					new.req_priority, 
					new.additional_info, 
					new.req_status, 
					new.approver1, 
					app1_name, 
					new.approver2, 
					app2_name, 
					new.approver3, 
					app3_name, 
					new.appstatus1, 
					new.appstatus2, 
					new.appstatus3, 
					new.isactive, 
					new.createdby, 
					new.modifiedby, 
					new.createdon, 
					new.modifiedon,createdbyname
					);
				    END