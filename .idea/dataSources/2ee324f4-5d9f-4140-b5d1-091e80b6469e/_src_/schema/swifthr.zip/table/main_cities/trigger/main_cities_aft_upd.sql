CREATE TRIGGER `main_cities_aft_upd`
AFTER UPDATE ON `main_cities`
FOR EACH ROW
  BEGIN
					if old.city != new.city then 
				        begin 
				           update main_interviewrounds_summary set interview_city_name = new.city,modified_date = utc_timestamp() where interview_city_id = new.city_org_id and isactive = 1;
				        end;
				        end if;
				    END