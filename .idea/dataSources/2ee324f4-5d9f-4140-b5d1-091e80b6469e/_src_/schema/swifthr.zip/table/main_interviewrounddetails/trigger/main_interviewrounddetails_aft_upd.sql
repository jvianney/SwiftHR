CREATE TRIGGER `main_interviewrounddetails_aft_upd`
AFTER UPDATE ON `main_interviewrounddetails`
FOR EACH ROW
  BEGIN
					declare cand_name,cstatus,istatus,int_name,cityname,statename,countryname varchar(255);
					select candidate_name,cand_status into cand_name,cstatus from main_candidatedetails where id = new.candidate_id and isactive =1;
					select userfullname into int_name from main_users where id = new.interviewer_id and isactive =1;
					
					select interview_status into istatus from main_interviewdetails where id = new.interview_id and isactive =1;
					select city into cityname from main_cities where city_org_id = new.int_city and isactive =1;
					select state into statename from main_states where state_id_org = new.int_state and isactive =1;
					select country into countryname from main_countries where country_id_org = new.int_country and isactive =1;
					update main_interviewrounds_summary set
					 candidate_name = cand_name,candidate_status = cstatus, interview_status = istatus,  
					interviewer_id = new.interviewer_id, interviewer_name = int_name, interview_time = new.interview_time,
					interview_date = new.interview_date, interview_mode = new.interview_mode, interview_round_number = new.interview_round_number, 
					interview_round_name = new.interview_round, interview_location = new.int_location, interview_city_id = new.int_city,
					interview_state_id = new.int_state, interview_city_name = cityname,interview_state_name = statename,
					interview_country_id = new.int_country, interview_country_name = countryname, interview_feedback = new.interview_feedback, 
					interview_comments = new.interview_comments, round_status = new.round_status, modified_by = new.modifiedby, 
					modified_date = new.modifieddate,isactive = new.isactive
					
					 where interviewround_id = new.id;
				    END