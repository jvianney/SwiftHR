CREATE TRIGGER `main_interviewrounddetails_aft_ins`
AFTER INSERT ON `main_interviewrounddetails`
FOR EACH ROW
  BEGIN
					declare cand_name,cstatus,istatus,int_name,cityname,statename,countryname,created_name varchar(255);
					select candidate_name,cand_status into cand_name,cstatus from main_candidatedetails where id = new.candidate_id and isactive =1;
					select userfullname into int_name from main_users where id = new.interviewer_id and isactive =1;
					select userfullname into created_name from main_users where id = new.createdby and isactive =1;
					select interview_status into istatus from main_interviewdetails where id = new.interview_id and isactive =1;
					select city into cityname from main_cities where city_org_id = new.int_city and isactive =1;
					select state into statename from main_states where state_id_org = new.int_state and isactive =1;
					select country into countryname from main_countries where country_id_org = new.int_country and isactive =1;
					insert into main_interviewrounds_summary 
					(requisition_id, candidate_id, candidate_name,candidate_status, interview_status, interview_id, interviewround_id, 
					interviewer_id, interviewer_name, interview_time, interview_date, interview_mode, interview_round_number, 
					interview_round_name, interview_location, interview_city_id, interview_state_id, interview_city_name, 
					interview_state_name, interview_country_id, interview_country_name, created_by, created_by_name, 
					interview_feedback, interview_comments, round_status, modified_by, created_date, modified_date, 
					isactive)
					values
					( new.req_id, new.candidate_id,	cand_name,cstatus,istatus,new.interview_id,new.id, 	
					new.interviewer_id,int_name,new.interview_time,new.interview_date,new.interview_mode,new.interview_round_number, 
					new.interview_round,new.int_location, 	new.int_city,new.int_state,cityname, 
					statename,new.int_country,countryname,new.createdby,created_name, 
					new.interview_feedback, new.interview_comments,	new.round_status,new.modifiedby, new.createddate, new.modifieddate, 
					new.isactive
					);
				    END