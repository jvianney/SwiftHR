CREATE TRIGGER `main_leavemanagement_aft_upd`
AFTER UPDATE ON `main_leavemanagement`
FOR EACH ROW
  BEGIN
				    declare calmonth_name,weekend_name1,weekend_name2,dept_name,buss_unit_name varchar(200);
				    declare bunit_id bigint(20);
				    select month_name into calmonth_name from tbl_months where monthid = new.cal_startmonth;
				    select week_name into weekend_name1 from tbl_weeks where week_id = new.weekend_startday;
				    select week_name into weekend_name2 from tbl_weeks where week_id = new.weekend_endday;
				    select b.id,concat(d.deptname," (",d.deptcode,")") ,
				    if(b.unitcode != "000",concat(b.unitcode,"","-"),"") into bunit_id,dept_name,buss_unit_name 
				    FROM `main_departments` AS `d` LEFT JOIN `main_businessunits` AS `b` ON b.id=d.unitid 
				    WHERE (d.isactive = 1 and d.id = new.department_id);
				    UPDATE  main_leavemanagement_summary set
				    cal_startmonth = new.cal_startmonth, 
				    cal_startmonthname = calmonth_name, 
				    weekend_startday = new.weekend_startday, 
				    weekend_startdayname = weekend_name1,
				    weekend_endday = new.weekend_endday, 
				    weekend_enddayname = weekend_name2, 
				    businessunit_id = bunit_id, 
				    businessunit_name = buss_unit_name, 
				    department_id = new.department_id, 
				    department_name = dept_name, 
				    hours_day = new.hours_day, 
				    is_satholiday = new.is_satholiday, 
				    is_halfday = new.is_halfday, 
				    is_leavetransfer = new.is_leavetransfer, 
				    is_skipholidays = new.is_skipholidays, 
				    description = new.description, 
				    createdby = new.createdby, 
				    modifiedby = new.modifiedby, 
				    createddate = new.createddate, 
				    modifieddate = new.modifieddate, 
				    isactive = new.isactive where leavemgmt_id = new.id;
				    END