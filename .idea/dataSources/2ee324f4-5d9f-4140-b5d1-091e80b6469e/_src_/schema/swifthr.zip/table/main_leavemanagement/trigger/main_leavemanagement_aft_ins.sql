CREATE TRIGGER `main_leavemanagement_aft_ins`
AFTER INSERT ON `main_leavemanagement`
FOR EACH ROW
  BEGIN
				    declare calmonth_name,weekend_name1,weekend_name2,dept_name,buss_unit_name varchar(200);
				    declare dept_id,bunit_id bigint(20);
				    select month_name into calmonth_name from tbl_months where monthid = new.cal_startmonth;
				    select week_name into weekend_name1 from tbl_weeks where week_id = new.weekend_startday;
				    select week_name into weekend_name2 from tbl_weeks where week_id = new.weekend_endday;
				    #select department_id into dept_id from main_employees where user_id = new.user_id;
				    select b.id,concat(d.deptname," (",d.deptcode,")") ,
				    if(b.unitcode != "000",concat(b.unitcode,"","-"),"") into bunit_id,dept_name,buss_unit_name 
				    FROM `main_departments` AS `d` LEFT JOIN `main_businessunits` AS `b` ON b.id=d.unitid 
				    WHERE (d.isactive = 1 and d.id = new.department_id);
				    insert into main_leavemanagement_summary (leavemgmt_id, cal_startmonth, cal_startmonthname, 
				    weekend_startday, weekend_startdayname, weekend_endday,weekend_enddayname, businessunit_id, 
				    businessunit_name, department_id, department_name, hours_day, is_satholiday, is_halfday, 
				    is_leavetransfer, is_skipholidays, description, createdby, modifiedby, createddate, 
				    modifieddate, isactive)
				    values(new.id,new.cal_startmonth, calmonth_name, new.weekend_startday, weekend_name1,
				    new.weekend_endday,weekend_name2,bunit_id, buss_unit_name, new.department_id, 
				    dept_name, new.hours_day, new.is_satholiday, new.is_halfday, new.is_leavetransfer, 
				    new.is_skipholidays, new.description,  new.createdby, new.modifiedby, new.createddate, 
				    new.modifieddate, new.isactive);
				    END