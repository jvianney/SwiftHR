CREATE TRIGGER `main_businessunits_main_requisition_summary`
AFTER UPDATE ON `main_businessunits`
FOR EACH ROW
  BEGIN
					UPDATE main_requisition_summary rs SET rs.businessunit_name = NEW.unitname, rs.modifiedon = utc_timestamp() WHERE (rs.businessunit_id = NEW.id 
					AND rs.businessunit_name != NEW.unitname);
				        UPDATE main_leaverequest_summary ls SET ls.buss_unit_name = if(NEW.unitcode != "000",concat(NEW.unitcode,"","-"),""), ls.modifieddate = utc_timestamp() 
				        WHERE (ls.bunit_id = NEW.id AND ls.isactive=1);
				        
				        update main_leavemanagement_summary lm set lm.businessunit_name = if(NEW.unitcode != "000",concat(NEW.unitcode,"","-"),""),lm.modifieddate = utc_timestamp() 
				        where lm.businessunit_id = new.id and lm.isactive = 1;
					#start of main_employees_summary
					update main_employees_summary set businessunit_name = new.unitname,modifieddate = utc_timestamp() where businessunit_id = new.id and isactive = 1;
					#end of main_employees_summary
				    END